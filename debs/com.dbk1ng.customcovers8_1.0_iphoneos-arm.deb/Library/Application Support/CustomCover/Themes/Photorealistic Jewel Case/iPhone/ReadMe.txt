Theme I threw together for SnowCover Simple on iOS 6 that I have made compatible for CustomCover. 
Works on jailbroken iPhones & iPod Touches on iOS 7.0 - 7.0.6



Have fun guys :-D

Daniel
@dbk1ng
