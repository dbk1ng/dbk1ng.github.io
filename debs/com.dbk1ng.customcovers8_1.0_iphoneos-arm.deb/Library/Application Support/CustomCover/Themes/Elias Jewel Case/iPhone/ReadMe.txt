HUGE thank you to Elias Keppens for allowing me to release his unnamed & unreleased Snowcover 4 theme,
& modifications of it for CustomCover. Compatible with jailbroken iPhones & iPod Touches on iOS 7.0 - 7.0.6


100% of the credit goes to him.

Please give him a follow, he's Goldly at pushing pixels ;)


On twitter- https://twitter.com/EliasKeppens


On dribbble- https://dribbble.com/EliasKeppens


& on deviantArt- http://elajes.deviantart.com



Have fun guys :-D

Daniel
@dbk1ng
